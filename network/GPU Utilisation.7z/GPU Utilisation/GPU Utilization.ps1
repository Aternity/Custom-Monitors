<#
.Synopsis
	Aternity  GPU Utilisation
.DESCRIPTION
	This script provides the sum of all GPU engine usage in %
	If 2 GPU exist, the sum can be 200%

.EXAMPLE
   N/A

.VERSION
Date : 20210119 V1.0 
Date : 20210120 V1.1 Add number of CPU and number of Monitors
Date : 03/29/2121 V1.2 Change the Catch method for exception message
#>
$sum = 0
$sum2 = 0
$MonitorNumber = 0

#logic and script
try
{
	# Load Agent Module
	Add-Type -Path $env:STEELCENTRAL_ATERNITY_AGENT_HOME\ActionExtensionsMethods.dll
	#Add-Type -AssemblyName PresentationCore,PresentationFramework

#Number of physical GPU
(Get-WmiObject -NameSpace root\cimV2 -Class win32_VideoController).videoProcessor | foreach { if ($_ -ne $null) {$sum2 += 1}}
[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("NumberOfGPU",$sum2 )

#Number of Monitor
$MonitorNumber = (Get-WmiObject -Class  Win32_DesktopMonitor).count
[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("NumberOfMonitor",$MonitorNumber)

#CPU %
(Get-Counter "\GPU Engine(*)\Utilization Percentage").countersamples.CookedValue | foreach { $sum += $_}
[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("GPUUtilization",$sum)

}
catch
{
    [ActionExtensionsMethods.PowershellPluginMethods]::SetFailed($_.Exception.Message)
}
#EOF
