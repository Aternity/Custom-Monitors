<#
.Synopsis
	Aternity  Ping Monitor
.DESCRIPTION
	This script provides for a specifix IP/Name an availability percentage and the request time

.EXAMPLE
	Need to set in variables the parameters
	Parameters : URL  : www.google.fr

#>



#####################Variables#####################
#      MANDATORY 
$IPTest = "www.aternity.com"
###################################################


#Variables
$ReponseCode = 0
$Availability = 0

#logic and script
try
{
	# Load Agent Module
	Add-Type -Path $env:STEELCENTRAL_ATERNITY_AGENT_HOME\ActionExtensionsMethods.dll
	#Add-Type -AssemblyName PresentationCore,PresentationFramework


$PingResponse = Test-NetConnection $IPTest

If  ( $PingResponse.PingSucceeded ) 
	{

	$Availability = 100
	#Output
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("Destination",$IPTest)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("InterfaceAlias",$PingResponse.InterfaceAlias)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("RemoteAddress",$PingResponse.RemoteAddress)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("Availability",$Availability)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("RTT",$PingResponse.PingReplyDetails.RoundtripTime/1000)
	}
else
	{
	$Availability = 0
	#Output
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("Destination",$IPTest)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("InterfaceAlias",$PingResponse.InterfaceAlias)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("RemoteAddress",$PingResponse.RemoteAddress)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("Availability",$Availability)
	}
}
catch
{
    [ActionExtensionsMethods.ActionExtensionsMethods]::SetFailed($_.Exception.Message)
}
#EOF
