<#
.Synopsis
	Aternity - monitor: DNSResponseTime
.DESCRIPTION
	Use case: Check DNS connection add speed
	Tested on Windows 10
	
	References:
	* https://www.aternity.com
	* https://help.aternity.com/search?facetreset=yes&q=remediation

.EXAMPLE

	Need to set in variables the parameters
	$dnsserver, $dnsName and $numberoftests

.VERSION
Date : 12/10/2020 V1.0
Date : 01/18/2121 V1.1 add a DNS clear cache in order to force DNS resolution from a request
Date : 03/29/2121 V1.2 Change the Catch method for exception message
#>


#####################Variables#####################
#      MANDATORY 
$dnsserver = "8.8.8.8"
$dnsName = "www.aternity.com"
$numberoftests = 10
###################################################


try
{
	# Load Agent Module
	
	Add-Type -Path $env:STEELCENTRAL_ATERNITY_AGENT_HOME\ActionExtensionsMethods.dll

	# Initialisation
	
	$totalmeasurement = 0
	$i = 0
	#Test
		while ($i -ne $numberoftests)
		{
			# Add a clear cache in order to force a DNS request
			Clear-DnsClientCache
			$measurement = Measure-Command {Resolve-DnsName $dnsName -Server "$($dnsserver)" -Type A}
			$totalmeasurement += $measurement.TotalSeconds
			write-host $dnsservers $dnsName $measurement.TotalSeconds
			$i += 1
		}

	$totalmeasurement = [math]::Round($totalmeasurement / $numberoftests,3)
	$StringDisplay=$dnsserver + ":" + $dnsName
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("DNSServerTest",$dnsserver)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("ResolvedName",$StringDisplay )
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("DNSResponseTime",$totalmeasurement)
	#write-host $result
}
catch
{
	[ActionExtensionsMethods.PowershellPluginMethods]::SetFailed($_.Exception.Message)
	exit 1
}
#EOF