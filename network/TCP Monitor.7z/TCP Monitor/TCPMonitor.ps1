<#
.Synopsis
	Aternity - monitor: TCPMonitor
.DESCRIPTION
	Use case: Check TCP connection
	Tested on Windows 10
	
	References:
	* https://www.aternity.com
	* https://help.aternity.com/search?facetreset=yes&q=remediation

.EXAMPLE

	Need to set in variables the parameters
	$IPTest ,$Port

.VERISON
Date : 12/10/2020 V1.0

#>
#####################Variables#####################
#	MANDATORY 
#
$IPTest = ""
$Port = 
####################################################


$IPPort = $IPTest + ":" + $Port
#Variables
$Availability = 0

#logic and script
try
{
	# Load Agent Module
	Add-Type -Path $env:STEELCENTRAL_ATERNITY_AGENT_HOME\ActionExtensionsMethods.dll
	#Add-Type -AssemblyName PresentationCore,PresentationFramework

$PingResponse = Test-Netconnection "$($IPTest)" -Port $Port

if($PingResponse.TcpTestSucceeded)
	{
	$Avail = 100
	#Output
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("IPPort",$IPPort )
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("TCPConnection",$Avail)
	}
else
	{
	$Avail = 0
	#Output
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("IPPort",$IPPort )
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("TCPConnection",$Avail)
	}
}
catch
{
	[ActionExtensionsMethods.ActionExtensionsMethods]::SetFailed($_.Exception.Message)
}
#EOF
