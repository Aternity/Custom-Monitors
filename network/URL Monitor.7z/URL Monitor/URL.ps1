<#
.Synopsis
	Aternity - Remediation Script: URL Monitor script
.DESCRIPTION
	This script provides for a specifix URL an availability percentage and the request time


.EXAMPLE
	This script will invoke an URL 
	Deploy in Aternity (Configuration > Remediation > Add Action) 
	Action Name: Syjnthetic-SiteName
	Parameters : URL  : https://www.google.fr

.VERSION
V1.0

DATE
14/12/2020
#>
#####################Variables#####################
#      MANDATORY 
$URLTest = "http://www.aternity.com"
###################################################


#Variables
$ReponseCode = 0
$TimeRequestBefore = 0
$TimeRequestAfter = 0
$RequestTime = 0
$Availability = 0

#logic and script
try
{
	# Load Agent Module
    Add-Type -Path $env:STEELCENTRAL_ATERNITY_AGENT_HOME\ActionExtensionsMethods.dll
    #Add-Type -AssemblyName PresentationCore,PresentationFramework

$TimeRequestbefore = Get-Date -Format HH:mm:ss.fff
$WebResponse = Invoke-WebRequest $URLTest
$TimeRequestAfter = Get-Date -Format HH:mm:ss.fff

If  ( $WebResponse.StatusCode -eq 200 ) 
	{
	$RequestTime = New-TimeSpan -Start $TimeRequestbefore -End $TimeRequestafter
	$Availability = 100
	#Output
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("URL",$URLTest)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("Availability",$Availability)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("Status Code",$WebResponse.StatusCode)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("Request Time",$RequestTime.TotalSeconds)
	}
else
	{
	$Availability = 0
	#Output
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueString("URL",$URL)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("Availability",$Availability)
	[ActionExtensionsMethods.PowershellPluginMethods]::SetAttributeValueDouble("Status Code",$WebResponse.StatusCode)
	}
}
catch
{
    [ActionExtensionsMethods.ActionExtensionsMethods]::SetFailed($_.Exception.Message)
}
#EOF
